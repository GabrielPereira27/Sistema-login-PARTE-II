<?php 
	session_start();
	$con = new mysqli("localhost", "root", "", "filmes");

	if ($con->connect_errno != 0) {
		echo "Ocorreu um erro no acesso à base de dados ".$con->connect_error;
		exit;
	}
	else{
		if (!isset($_SESSION['login'])) {
			$_SESSION['login']="incorreto";
		}
		if ($_SESSION['login']=="correto") {
		}
	}
?>
	<!DOCTYPE html>
	<html>
	<head style="background:color:black;">
	<meta charset="ISO-8859-1">
		<title>Filmes</title>
	</head>
	<body>
			<a style="text-align:right;" href="login.php">Logout</a>
<?php 

	if ($_SESSION['login']=="correto") {
				include "inc_filmes.php";
				include "inc_atores.php";
				include "inc_realizadores.php";
				include "inc_utilizadores.php";
			}

else {
	echo 'Para entrar nesta página necessita de efetuar <a href="login.php">Login</a>';
	header('refresh:2;url=login.php');
	}
?>
</body>
	</html>
