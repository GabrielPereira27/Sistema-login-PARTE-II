<?php 
	if ($_SERVER['REQUEST_METHOD'] == "POST") 
	{
		$nome = "";
		$user_name = "";
		$email = "";
		$password = "";

		if (isset($_POST['nome'])) {
			$nome = $_POST['nome'];
		}
		else {
			echo '<script> alert("É obrigatorio o preenchimento do nome do utilizador.");</script>';
		}
		if (isset($_POST['user_name'])) {
			$user_name = $_POST['user_name'];
		}
		if (isset($_POST['email'])) {
			$email = $_POST['email'];
		}
		if (isset($_POST['password'])) {
			$password = $_POST['password'];
		}
		$con = new mysqli("localhost", "root", "", "filmes");

		if($con -> connect_errno != 0){
			echo 'Ocorreu um erro no acesso à base de dados. <br>'.$con ->connect_error;
			exit();
		}
	else {
			$sql = 'insert into utilizadores (nome, user_name, email, password) values (?,?,?)';
			$stm = $con -> prepare($sql);

			if ($stm != false) {
				password_hash($pwd, PASSWORD_DEFAULT);
				$stm-> bind_param('ssss', $nome, $user_name, $email, $password);
				$stm-> execute();
				$stm-> close();
				header("refresh:5; url=index.php");

				echo '<script>alert("utilizador adicionado com sucesso!");</script>';
				echo 'Aguarde um momento. A reencaminhar página';
				header("refresh:5; url=index.php");
			}
		}
	}
	else { // 
?>
	<!DOCTYPE html>
	<html>
	<head>
		<meta charset="ISO-8859-1">
		<title>Adicionar Utilizadores</title>
	</head>
	<body>
		<h1>Adicionar utilizadores:</h1>
		<i class="bi bi-file-plus"></i>
		<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" fill="currentColor" class="bi bi-file-plus" viewBox="0 0 16 16">
  <path fill-rule="evenodd" d="M4 0h8a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V2a2 2 0 0 1 2-2zm0 1a1 1 0 0 0-1 1v12a1 1 0 0 0 1 1h8a1 1 0 0 0 1-1V2a1 1 0 0 0-1-1H4z"/>
  <path fill-rule="evenodd" d="M8 5.5a.5.5 0 0 1 .5.5v1.5H10a.5.5 0 0 1 0 1H8.5V10a.5.5 0 0 1-1 0V8.5H6a.5.5 0 0 1 0-1h1.5V6a.5.5 0 0 1 .5-.5z"/>
</svg>
		<form action="utilizadores_create.php" method="post">
			<label>Nome</label><input type="text" name="nome" required><br><br>
			<label>User Name</label><input type="text" name="user_name"><br><br>
			<label>Email</label><input type="text" name="email"><br><br>
			<label>Password</label><input type="text" name="password"><br><br>
			<input type="submit" name="enviar"><br>
		</form>
	</body>
		<script src="js/jquery-3.5.1.min.js"></script>
	<script src="js/bootstrap.js"></script>
	</html>

	<?php 
		}
	?>