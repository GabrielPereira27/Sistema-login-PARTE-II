<!DOCTYPE html>
<html>
<head>
<meta charset="ISO-8859-1">
	<title>Login</title>
</head>
<body>
<h1>Login</h1>
<form method="post" action="processa_login.php">
	<label><b>Nome de Utilizador</b></label><input type="text" name="user_name" required><br><br>
	<label><b>Palavra-passe</b></label><input type="text" name="password" required>
	<input type="submit" name="login">	
</form>
</body>
</html>